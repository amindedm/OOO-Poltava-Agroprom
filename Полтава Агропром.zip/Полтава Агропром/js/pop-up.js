let message = 'Hello!';
alert(message);